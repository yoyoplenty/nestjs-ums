export interface IBaseSchema {
  _id: string;
  createdAt: Date;
  updatedAt?: Date;
}
