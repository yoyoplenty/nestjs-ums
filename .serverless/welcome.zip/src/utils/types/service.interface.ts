export interface IBaseService<R> {}
