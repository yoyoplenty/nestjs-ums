export interface ResponseDTO {
  success: boolean;
  data: null | object;
  message: string;
}
