export enum ROLE {
  USER = 'user',
  ADMIN = 'admin',
}
